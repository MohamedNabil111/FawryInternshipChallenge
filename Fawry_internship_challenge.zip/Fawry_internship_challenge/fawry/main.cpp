#include<iostream>
#include <vector>
#include <string>
#include <map>
#include <ctime>
#include"Date.h"
#include"Cart.h"
#include"Customer.h"
#include"Shippable.h"
#include"ShippableProduct.h"
#include"ShippableService.h"
#include"Checkout.h"
using namespace std;

//to get today's date
Date getCurrentDate() {
    time_t now = time(0);
    tm local = {};
    localtime_s(&local, &now);
    return {
        local.tm_year + 1900,
        local.tm_mon + 1,
        local.tm_mday
    };
}

//test functions
void test_successful_checkout() {
    cout << "-----------------*****-----------------\n";
    cout << "testing successful checkout\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 10000);

    bool ok = true;
    ok &= customer.addToCart(&tv, 1);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

void test_expired_product() {
    cout << "-----------------*****-----------------\n";
    cout << "testing expired product\n";

    Date today = getCurrentDate();
    Date expiredDate(today.year, today.month, today.day - 1);
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct expiredMilk("Milk", 15, 10, expiredDate);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 10000);

    bool ok = true;
    ok &= customer.addToCart(&tv, 1);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);
    ok &= customer.addToCart(&expiredMilk, 1);

    if (ok) checkout(customer);
    cout << endl;
}

void test_insufficient_balance() {
    cout << "-----------------*****-----------------\n";
    cout << "testing insufficient balance\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 1000);

    bool ok = true;
    ok &= customer.addToCart(&tv, 1);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

void test_empty_cart() {
    cout << "-----------------*****-----------------\n";
    cout << "testing empty cart\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 1000);

    bool ok = true;

    if (ok) checkout(customer);
    cout << endl;
}

void test_quantity_limit() {
    cout << "-----------------*****-----------------\n";
    cout << "testing quantity limit\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 1000);

    bool ok = true;
    ok &= customer.addToCart(&tv, 6);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

void test_non_shippable_checkout() {
    cout << "-----------------*****-----------------\n";
    cout << "testing non shippable checkout\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 10000);

    bool ok = true;
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

void test_perishable_and_shippable_product() {
    cout << "-----------------*****-----------------\n";
    cout << "testing perishable and shippable product\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 10000);

    bool ok = true;
    ok &= customer.addToCart(&tv, 1);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

void test_zero_or_negative_quantity() {
    cout << "-----------------*****-----------------\n";
    cout << "testing zero or negative quantity\n";

    Date today = getCurrentDate();
    Date futureDate(today.year, today.month, today.day + 5);

    ShippableProduct tv("Samsung TV", 8000, 5, 5.0);
    ShippableProduct biscuits("Biscuits", 20, 10, 0.7);
    PerishableProduct freshCheese("Cheese", 40, 10, futureDate);

    Customer customer("Ali", 10000);

    bool ok = true;
    ok &= customer.addToCart(&tv, -1);
    ok &= customer.addToCart(&biscuits, 2);
    ok &= customer.addToCart(&freshCheese, 3);

    if (ok) checkout(customer);
    cout << endl;
}

int main() {
    test_successful_checkout();
    test_perishable_and_shippable_product();
    test_non_shippable_checkout();
    test_expired_product();
    test_insufficient_balance();
    test_empty_cart();
    test_quantity_limit();
    test_zero_or_negative_quantity();
    return 0;
}