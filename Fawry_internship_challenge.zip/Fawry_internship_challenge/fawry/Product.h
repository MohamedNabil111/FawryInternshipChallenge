#pragma once
#include"Date.h"
#include<string>
using namespace std;

class Product {
protected:
    string name;
    double price;
    int quantity;

public:
    Product(string name, double price, int quantity)
        : name(name), price(price), quantity(quantity) {
    }

    string getName() const { return name; }
    double getPrice() const { return price; }
    int getQuantity() const { return quantity; }

    void reduceQuantity(int amount) {
        quantity -= amount;
    }

    virtual ~Product() {}
};

class PerishableProduct : public Product {
private:
    Date expiryDate;

public:
    PerishableProduct(string name, double price, int quantity, const Date& expiryDate)
        : Product(name, price, quantity), expiryDate(expiryDate) {
    }

    bool isExpired(const Date& today) const {
        return expiryDate < today;
    }

    const Date& getExpiryDate() const {
        return expiryDate;
    }
};
