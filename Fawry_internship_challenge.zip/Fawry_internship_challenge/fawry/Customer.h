#pragma once
#include<iostream>
#include"Cart.h"

class Customer {
private:
    string name;
    double balance;
    Cart cart;

public:
    Customer(string name, double balance)
        : name(name), balance(balance) {
    }

    string getName() const { return name; }
    double getBalance() const { return balance; }

    bool addToCart(Product* product, int quantity) {
        return cart.add(product, quantity);
    }

    Cart& getCart() {
        return cart;
    }

    void reduceBalance(double amount) {
        balance -= amount;
    }

    void printBalance() const {
        cout << "Remaining Balance: " << balance << endl;
    }

    bool hasEnoughBalance(double amount) const {
        return balance >= amount;
    }
};