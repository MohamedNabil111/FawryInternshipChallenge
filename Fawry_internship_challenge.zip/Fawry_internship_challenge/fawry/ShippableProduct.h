#pragma once
#include"Product.h"
#include"Shippable.h"

class ShippableProduct : public Product, public Shippable {
private:
    double weight; // in kg

public:
    ShippableProduct(string name, double price, int quantity, double weight)
        : Product(name, price, quantity), weight(weight) {
    }

    double getWeight() const override { return weight; }
    string getName() const override { return name; }
};