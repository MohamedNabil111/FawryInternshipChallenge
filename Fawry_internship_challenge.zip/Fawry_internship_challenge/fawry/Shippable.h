#pragma once
#include<string>

// abstract class for the interface
class Shippable {
public:
    virtual std::string getName() const = 0;
    virtual double getWeight() const = 0;
    virtual ~Shippable() {}
};