#pragma once
#include<iostream>
#include"Shippable.h"
#include<vector>
#include<map>
using namespace std;

class ShippingService {
public:
    static void shipItems(const vector<Shippable*>& items) {
        if (items.empty()) return;

        cout << "** Shipment notice **\n";
        double totalWeight = 0.0;

        // Count duplicates (2x Cheese etc.)
        map<string, pair<int, double>> itemInfo;

        for (auto item : items) {
            itemInfo[item->getName()].first++;
            itemInfo[item->getName()].second = item->getWeight();
            totalWeight += item->getWeight();
        }

        for (const auto& pair : itemInfo) {
            string name = pair.first;
            int count = pair.second.first;
            double weight = pair.second.second;
            cout << count << "x " << name << "\t" << int(count * weight * 1000) << "g\n";
        }

        cout << "Total package weight " << totalWeight << "kg\n\n";
    }
};