#pragma once
#include<iostream>
#include"Product.h"
#include<vector>
using namespace std;

struct CartItem {
    Product* product;
    int quantity;

    CartItem(Product* product, int quantity)
        : product(product), quantity(quantity) {
    }
};

class Cart {
private:
    vector<CartItem> items;

public:
    bool add(Product* product, int quantity) {
        if (quantity <= 0) {
            cout << "Quantity of the item '" << product->getName() << "' must be positive.\n";
            return false;
        }
        if (product->getQuantity() < quantity) {
            cout << "Not enough stock for product: " << product->getName() << "\n";
            return false;
        }

        product->reduceQuantity(quantity);

        items.push_back(CartItem(product, quantity));
        return true;
    }

    double getSubtotal() const {
        double subtotal = 0.0;
        for (const auto& item : items) {
            subtotal += item.product->getPrice() * item.quantity;
        }
        return subtotal;
    }

    bool isEmpty() const {
        return items.empty();
    }

    const vector<CartItem>& getItems() const {
        return items;
    }

    void clear() {
        items.clear();
    }
};