#pragma once
#include"Customer.h"
#include"Shippable.h"
#include"ShippableService.h"

void checkout(Customer& customer) {
    Cart& cart = customer.getCart();

    if (cart.isEmpty()) {
        cout << "Error: Cart is empty.\n";
        return;
    }

    double subtotal = cart.getSubtotal();
    double shippingFee = 0.0;
    double totalWeight = 0.0;
    vector<Shippable*> itemsToShip;

    for (const CartItem& item : cart.getItems()) {
        Product* product = item.product;

        PerishableProduct* perishable = dynamic_cast<PerishableProduct*>(product);
        if (perishable) {
            Date today = getCurrentDate();
            if (perishable->isExpired(today)) {
                cout << "Error: Product '" << product->getName() << "' is expired.\n";
                return;
            }
        }

        Shippable* shippable = dynamic_cast<Shippable*>(product);
        if (shippable) {
            for (int i = 0; i < item.quantity; ++i) {
                itemsToShip.push_back(shippable);
                totalWeight += shippable->getWeight();
            }
        }
    }

    if (!itemsToShip.empty()) {
        shippingFee = totalWeight * 30.0; // 30 per Kg
    }

    double totalAmount = subtotal + shippingFee;

    if (!customer.hasEnoughBalance(totalAmount)) {
        cout << "Error: Insufficient balance.\n";
        return;
    }

    customer.reduceBalance(totalAmount);

    if (!itemsToShip.empty()) {
        ShippingService::shipItems(itemsToShip);
    }

    cout << "** Checkout receipt **\n";
    for (const CartItem& item : cart.getItems()) {
        cout << item.quantity << "x " << item.product->getName() << "\t" << item.product->getPrice() * item.quantity << "\n";
    }
    cout << "----------------------\n";
    cout << "Subtotal\t" << subtotal << "\n";
    cout << "Shipping\t" << shippingFee << "  (" << totalWeight << " * 30.0)" << "\n";
    cout << "Amount\t\t" << totalAmount << "\n";
    cout << endl;

    customer.printBalance();
    cart.clear();
}