#pragma once
#include<ctime>
struct Date {
    int year, month, day;

    Date(int y = 0, int m = 0, int d = 0) : year(y), month(m), day(d) {}

    bool operator<(const Date& other) const {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }
};

Date getCurrentDate();